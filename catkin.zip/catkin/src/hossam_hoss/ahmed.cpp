#include <iostream>

using main()
{

cout << "I'm software engineer!" << endl;

return 0;

}


